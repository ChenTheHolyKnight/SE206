java -jar *.jar &>/dev/null
