Before you run the program, make sure you have:
1.HTK installed in your computer
2.java oracle JDK 8 above
3.A microphone that can record your voice clearly

Warning:
1.Please do not delete any file in this folder otherwise the program will crash
2.Please do not seperate any file in this folder(make sure run.sh,a3.jar and HTK folders are in the same directory)
3.Please do not modify anything within this folder
4.Please do not run the program through the source code
5.Please do not replace/delete/rename anyfile when unzip the zipped file(if it complains the size of the file, please skip it when unzip the zipped file)

Running the program:
1.Open the terminal in the directory where it contains run.sh and a3.jar
2.Type ./run.sh in terminal to run the program


Clarification:
This is the Beta version of the final project. More feactures such as rewarding part will be added in the beta version. The source code is not fully commented due to the fact that introducing new feature may change the implementation of some classes. In the source code, there are some dead code and testing script as well. Please ignore them because they will be deleted in the final project.
According to the Academic Integrity, please do not copy any code from this Beta version of our final project
